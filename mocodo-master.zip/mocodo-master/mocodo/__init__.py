import sys

if "ipykernel" in sys.modules:
    from . import magic_command
