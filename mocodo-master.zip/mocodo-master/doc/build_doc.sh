jupyter nbconvert --to html_toc doc/fr_refman.ipynb && rm -r doc/fr_refman_files
